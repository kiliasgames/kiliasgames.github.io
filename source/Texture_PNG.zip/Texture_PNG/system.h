// Copyright (C) 2022 Kilias

#pragma once

#include <SDL.h>
#include <SDL_image.h>

namespace System
{
    SDL_Window* window;
    SDL_Renderer* renderer;
    SDL_Texture* image_texture;
    int text_width, text_height;
    int window_width, window_height;

    void init(const char* title, int width, int height)
    {
        window_width = width;
        window_height = height;

        SDL_Init(SDL_INIT_VIDEO);
        IMG_Init(IMG_INIT_PNG);

        window = SDL_CreateWindow(title, SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, width, height, SDL_WINDOW_SHOWN);

        renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    }

    void load_texture(const char* file)
    {
        auto source_image = IMG_Load(file);
        image_texture = SDL_CreateTextureFromSurface(renderer, source_image);
        SDL_FreeSurface(source_image);
    }

    void run(void (*update)())
    {
        auto quit = false;
        SDL_Event e;

        while (!quit)
        {
            while (!quit && SDL_PollEvent(&e) != 0)
                quit = e.type == SDL_QUIT;

            SDL_RenderClear(renderer);

            update();

            SDL_RenderPresent(renderer);
        }
    }

    void render_texture()
    {
        const auto w = 600;
        const auto h = 600;
        SDL_Rect rect;
        rect.x = (window_width - w) / 2;
        rect.y = (window_height - h) / 2;
        rect.w = w;
        rect.h = h;

        SDL_RenderCopy(renderer, image_texture, nullptr, &rect);
    }

    void clear()
    {
        SDL_DestroyTexture(image_texture);

        SDL_DestroyRenderer(renderer);

        SDL_DestroyWindow(window);

        IMG_Quit();
        SDL_Quit();
    }
}
