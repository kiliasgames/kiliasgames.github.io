// Copyright (C) 2022-2023 Kilias Games

#include "system.h"

int main(int argc, char* args[])
{
    System::init("Texture PNG", 800, 600);

    System::load_texture("image.png");

    System::run(&System::render_texture);

    System::clear();

    return 0;
}