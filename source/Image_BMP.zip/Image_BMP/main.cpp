// Copyright (C) 2022-2023 Kilias Games

#include "system.h"

int main(int argc, char* args[])
{
    System::init("Image BMP", 800, 600);

    System::load_and_draw_image("image.bmp");

    System::run();

    System::clear();

    return 0;
}