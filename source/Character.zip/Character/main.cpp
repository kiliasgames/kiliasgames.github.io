// Copyright (C) 2022 Kilias

#include "system.h"
#include <string>

int clicks_count = 0;

void create_text();
void render();
void handle_click();

std::string characters[3] = { "S", "D", "L" };

int main(int argc, char* args[])
{
    SDL_Color bg_color = { 50, 50, 50 };
    System::init("Character", 800, 600, bg_color);

    System::load_texture("image.png");
    create_text();

    System::run(&render, &handle_click);

    System::clear();

    return 0;
}

void create_text()
{
    clicks_count %= 3;
    auto& clicks = characters[clicks_count];
    SDL_Color font_color = { 0, 0, 0, 150 };
    System::create_text(clicks.c_str(), "LiberationSans-Regular.ttf", 200, font_color);
}

void render()
{
    System::render_image();
    System::render_text();
}

void handle_click()
{
    clicks_count++;
    System::clear_text();
    create_text();
}