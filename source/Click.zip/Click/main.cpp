// Copyright (C) 2022 Kilias

#include "system.h"
#include <string>

int clicks_count = 0;

void create_text();
void handle_click();

int main(int argc, char* args[])
{
    SDL_Color bg_color = { 50, 50, 50 };
    System::init("Click", 800, 600, bg_color);

    create_text();

    System::run(&System::render_text, &handle_click);

    System::clear();

    return 0;
}

void create_text()
{
    auto clicks = std::string("Clicks: ") + std::to_string(clicks_count);
    SDL_Color font_color = { 255, 255, 255 };
    System::create_text(clicks.c_str(), "LiberationSans-Regular.ttf", 72, font_color);
}

void handle_click()
{
    clicks_count++;
    System::clear_text();
    create_text();
}