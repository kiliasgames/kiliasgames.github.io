// Copyright (C) 2022 Kilias

#pragma once

#include <SDL.h>
#include <SDL_ttf.h>

namespace System
{
    SDL_Window* window;
    SDL_Renderer* renderer;
    SDL_Texture* text_texture;
    int text_width, text_height;
    int window_width, window_height;
    SDL_Color window_color;

    void init(const char* title, int width, int height, SDL_Color color)
    {
        window_width = width;
        window_height = height;
        window_color = color;

        SDL_Init(SDL_INIT_VIDEO);
        TTF_Init();

        window = SDL_CreateWindow(title, SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, width, height, SDL_WINDOW_SHOWN);

        renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
        SDL_SetRenderDrawColor(renderer, window_color.r, window_color.g, window_color.b, window_color.a);
    }

    void create_text(const char* text, const char* font_file, int size, SDL_Color color)
    {
        auto font = TTF_OpenFont(font_file, size);
        auto text_surface = TTF_RenderText_Solid(font, text, color);

        TTF_CloseFont(font);

        text_width = text_surface->w;
        text_height = text_surface->h;

        text_texture = SDL_CreateTextureFromSurface(renderer, text_surface);

        SDL_FreeSurface(text_surface);
    }

    void render_text();

    void run(void (*update)())
    {
        auto quit = false;
        SDL_Event e;

        while (!quit)
        {
            while (!quit && SDL_PollEvent(&e) != 0)
                quit = e.type == SDL_QUIT;

            SDL_SetRenderDrawColor(renderer, window_color.r, window_color.g, window_color.b, window_color.a);
            SDL_RenderClear(renderer);

            update();

            SDL_RenderPresent(renderer);
        }
    }

    void render_text()
    {
        SDL_Rect text_rect;
        text_rect.x = (window_width - text_width) / 2;
        text_rect.y = (window_height - text_height) / 2;
        text_rect.w = text_width;
        text_rect.h = text_height;

        SDL_RenderCopy(renderer, text_texture, NULL, &text_rect);
    }

    void clear()
    {
        SDL_DestroyTexture(text_texture);

        SDL_DestroyRenderer(renderer);

        SDL_DestroyWindow(window);

        TTF_Quit();
        SDL_Quit();
    }
}