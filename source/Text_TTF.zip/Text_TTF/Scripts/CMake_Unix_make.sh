cd ..
cmake --preset=Unix_make