// Copyright (C) 2022-2023 Kilias Games

#include "system.h"

int main(int argc, char* args[])
{
    SDL_Color bg_color = { 50, 50, 50 };
    System::init("Text TTF", 800, 600, bg_color);

    SDL_Color font_color = { 255, 255, 255 };
    System::create_text("HEY!", "LiberationSans-Regular.ttf", 72, font_color);

    System::run(&System::render_text);

    System::clear();

    return 0;
}