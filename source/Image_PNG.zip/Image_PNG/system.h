// Copyright (C) 2022 Kilias

#pragma once

#include <SDL.h>
#include <SDL_image.h>

namespace System
{
    SDL_Window* window;
    SDL_Surface* window_surface;
    SDL_Surface* image;

    void init(const char* title, int width, int height)
    {
        SDL_Init(SDL_INIT_VIDEO);

#ifdef __APPLE__
        SDL_SetHint(SDL_HINT_FRAMEBUFFER_ACCELERATION, "opengl");
#endif

        window = SDL_CreateWindow(title, SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, width, height, SDL_WINDOW_SHOWN);
        IMG_Init(IMG_INIT_PNG);
    }

    void load_and_draw_image(const char* image_file)
    {
        auto source_image = IMG_Load(image_file);
        window_surface = SDL_GetWindowSurface(window);
        image = SDL_ConvertSurface(source_image, window_surface->format, 0);
        SDL_FreeSurface(source_image);

        SDL_BlitSurface(image, nullptr, window_surface, nullptr);
        SDL_UpdateWindowSurface(window);
    }

    void run()
    {
        auto quit = false;
        SDL_Event e;

        while (!quit)
            while (!quit && SDL_PollEvent(&e) != 0)
                quit = e.type == SDL_QUIT;
    }

    void clear()
    {
        SDL_FreeSurface(image);

        SDL_DestroyWindow(window);

        IMG_Quit();
        SDL_Quit();
    }
}